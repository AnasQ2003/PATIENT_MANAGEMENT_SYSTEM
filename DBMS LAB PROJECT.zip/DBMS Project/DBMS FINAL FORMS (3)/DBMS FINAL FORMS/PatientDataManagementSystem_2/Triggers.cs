﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDataManagementSystem_2
{
    public partial class Triggers : Form
    {
        public Triggers()
        {
            InitializeComponent();
        }

        public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";


        private void TriggerPreventSalaryUpdate(int Salary,int id)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("UPDATE Doctors SET Salary = @Salary WHERE Doctor_Id = @id", connection))
                {
                    command.Parameters.AddWithValue("@id", id);
                    command.Parameters.AddWithValue("@Salary", Salary);
                    try
                    {
                        // Execute the update query
                        command.ExecuteNonQuery();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                        return;
                    }
                }

                // Create a SqlDataAdapter to retrieve the output of the trigger as a text value
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT CAST(1 AS varchar(30)) AS TriggerOutput", connection);

                // Create a DataTable to store the retrieved data
                DataTable dataTable = new DataTable();

                // Fill the DataTable with the data from the SqlDataAdapter
                adapter.Fill(dataTable);

                // Create a new column in the DataTable to display the trigger output
                dataTable.Columns.Add("TriggerOutputColumn", typeof(string));

                // Iterate through each row in the DataTable and assign the trigger output value to the new column
                foreach (DataRow row in dataTable.Rows)
                {
                    // Assuming the trigger output is stored in the first column of the DataTable
                    string triggerOutput = row[0].ToString();
                    row["TriggerOutputColumn"] = triggerOutput;
                }

                // Set the DataTable as the data source for the DataGridView
                dataGridView1.DataSource = dataTable;
               
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id= int.Parse(textBox1.Text);
            int Salary = int.Parse(textBox4.Text);

            TriggerPreventSalaryUpdate(Salary, id);
        }

        private void TriggerBillCheck(int id, String name,string date,int billAmount)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("Insert into PatientDischarge (Patient_ID,Patient_Name,DischargeDate,Bill_Amount) values (@id,@name,@date,@billAmount)", connection))
                {
                    command.Parameters.AddWithValue("@id", id);
                    command.Parameters.AddWithValue("@name", name);
                    command.Parameters.AddWithValue("@date", date);
                    command.Parameters.AddWithValue("@billAmount", billAmount);

                    try
                    {
                        // Execute the update query
                        command.ExecuteNonQuery();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                        return;
                    }
                }

                // Create a SqlDataAdapter to retrieve the output of the trigger as a text value
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT CAST(1 AS varchar(30)) AS TriggerOutput", connection);

                // Create a DataTable to store the retrieved data
                DataTable dataTable = new DataTable();

                // Fill the DataTable with the data from the SqlDataAdapter
                adapter.Fill(dataTable);

                // Create a new column in the DataTable to display the trigger output
                dataTable.Columns.Add("TriggerOutputColumn", typeof(string));

                // Iterate through each row in the DataTable and assign the trigger output value to the new column
                foreach (DataRow row in dataTable.Rows)
                {
                    // Assuming the trigger output is stored in the first column of the DataTable
                    string triggerOutput = row[0].ToString();
                    row["TriggerOutputColumn"] = triggerOutput;
                }

                // Set the DataTable as the data source for the DataGridView
                dataGridView1.DataSource = dataTable;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int id = int.Parse(textBox5.Text);
            String name = textBox6.Text;
            String date = textBox7.Text;
            int billAmount = int.Parse(textBox8.Text);
            TriggerBillCheck(id, name, date, billAmount);

        }
    }
}
