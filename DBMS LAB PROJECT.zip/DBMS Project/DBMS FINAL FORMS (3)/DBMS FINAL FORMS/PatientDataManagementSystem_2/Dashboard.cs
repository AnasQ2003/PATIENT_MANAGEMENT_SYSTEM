﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDataManagementSystem_2
{
    public partial class Dashboard : Form
    {

        private Button currentSelectedButton;
        public Dashboard()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            button1.BackColor = Color.Silver;
            currentSelectedButton = button1 as Button;



        }

        private void button_Click(object sender, EventArgs e)
        {
            // Check if the button is already selected
            if (currentSelectedButton != null && currentSelectedButton != sender)
            {
                // Reset the color of the previously selected button
                currentSelectedButton.BackColor = Color.FromArgb(56, 56, 71);
            }

            // Set the color of the clicked button
            Button clickedButton = (Button)sender;
            clickedButton.BackColor = Color.Silver; // Set the desired color for the selected button

            // Update the currently selected button
            currentSelectedButton = clickedButton;
        }




        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }


        private void button8_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {

            PatientRegistrationModule patientRegistrationModule = new PatientRegistrationModule();
            patientRegistrationModule.Show();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button_Click(sender, e);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button_Click(sender, e);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button_Click(sender, e);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button_Click(sender, e);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button_Click(sender, e);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            EHR_Module EHR_module = new EHR_Module();
            EHR_module.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            AppScheduling_Module appScheduling_Module = new AppScheduling_Module();
            appScheduling_Module.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Billing_Module billing_Module = new Billing_Module();
            billing_Module.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            HealthcareProviders_Module healthcareProviders_Module = new HealthcareProviders_Module();
            healthcareProviders_Module.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

            PatientRegistrationModule patientRegistrationModule = new PatientRegistrationModule();
            patientRegistrationModule.Show();
        }

        private void button13_Click_1(object sender, EventArgs e)
        {

            EHR_Module EHR_module = new EHR_Module();
            EHR_module.Show();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {

            AppScheduling_Module appScheduling_Module = new AppScheduling_Module();
            appScheduling_Module.Show();
        }

        private void button12_Click_1(object sender, EventArgs e)
        {

            Billing_Module billing_Module = new Billing_Module();
            billing_Module.Show();
        }

        private void button11_Click_1(object sender, EventArgs e)
        {

            HealthcareProviders_Module healthcareProviders_Module = new HealthcareProviders_Module();
            healthcareProviders_Module.Show();
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            Ward_Info ward_Info = new Ward_Info();
            ward_Info.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Patient_Ward patient_Ward = new Patient_Ward();
            patient_Ward.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            button_Click(sender, e);

            Views views = new Views();
            views.Show();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            button_Click(sender, e);

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            Patient_Bill patient_Bill = new Patient_Bill();
            patient_Bill.Show();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Patient_App patient_App = new Patient_App();
            patient_App.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            button_Click(sender, e);
            StoredProcedures storedProcedures = new StoredProcedures();
            storedProcedures.Show();

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            button_Click(sender, e);
            Functions functions = new Functions();
            functions.Show();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            button_Click(sender, e);
            Triggers triggers = new Triggers();
            triggers.Show();
        }
    }
}
