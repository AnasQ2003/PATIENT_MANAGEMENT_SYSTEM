﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PatientDataManagementSystem_2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";


        private void button1_Click(object sender, EventArgs e)
        {


            SqlConnection connection = new SqlConnection(connectionString);
            

                connection.Open();
                string query = "INSERT INTO Demo (id,Name,age) VALUES (@id, @Name, @age)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@id",int.Parse(textBox1.Text));
                command.Parameters.AddWithValue("@Name", textBox2.Text);
                command.Parameters.AddWithValue("@age", int.Parse(textBox3.Text));
                int rowsAffected = command.ExecuteNonQuery();
                Console.WriteLine($"{rowsAffected} rows inserted.");
                connection.Close();
            

        }
    }
}
