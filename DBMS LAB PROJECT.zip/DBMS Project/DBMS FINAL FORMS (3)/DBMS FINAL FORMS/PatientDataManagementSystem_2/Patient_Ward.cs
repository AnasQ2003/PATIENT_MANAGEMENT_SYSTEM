﻿namespace PatientDataManagementSystem_2
{
    public partial class Patient_Ward : Form
    {
        public Patient_Ward()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PatientWard pw = new PatientWard();

            pw.WardNo = int.Parse(textBox1.Text);
            pw.PatientId = int.Parse(textBox7.Text);
            pw.AdmitDate = textBox2.Text;
            pw.DischargeDate = textBox3.Text;


            pw.addPatientWard(pw.WardNo, pw.PatientId, pw.AdmitDate, pw.DischargeDate);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PatientWard pw = new PatientWard();

            pw.WardNo = int.Parse(textBox1.Text);
            pw.PatientId = int.Parse(textBox7.Text);
            pw.AdmitDate = textBox2.Text;
            pw.DischargeDate = textBox3.Text;


            pw.updatePatientWard(pw.WardNo, pw.PatientId, pw.AdmitDate, pw.DischargeDate);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            PatientWard pw = new PatientWard();


            pw.PatientId = int.Parse(textBox7.Text);
            pw.readDataWard(pw.PatientId);

            textBox1.Text = pw.WardNo.ToString();
            textBox2.Text = pw.AdmitDate.ToString();
            textBox3.Text = pw.DischargeDate.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            PatientWard pw = new PatientWard();
            pw.PatientId = int.Parse(textBox7.Text);


            pw.deletePatientWard(pw.PatientId);
        }

  
    }
}
