﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDataManagementSystem_2
{
    public partial class AppScheduling_Module : Form
    {
        public AppScheduling_Module()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Appointment appointment = new Appointment();

            appointment.AppointmentId = int.Parse(textBox1.Text);
            appointment.PatientId = int.Parse(textBox5.Text);
            appointment.PatientName = textBox7.Text;
            appointment.age = int.Parse(textBox4.Text);           
            appointment.gender = textBox2.Text;
            appointment.Phone = int.Parse(textBox10.Text);
            appointment.DoctorName = textBox6.Text;
            appointment.date = textBox8.Text;
            appointment.time = textBox9.Text;
            appointment.addPatientAppointment(appointment.AppointmentId, appointment.PatientId, appointment.PatientName, appointment.age, appointment.gender, appointment.Phone, appointment.DoctorName, appointment.date, appointment.time);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Appointment appointment = new Appointment();

            appointment.AppointmentId = int.Parse(textBox1.Text);
            appointment.PatientId = int.Parse(textBox5.Text);
            appointment.PatientName = textBox7.Text;
            appointment.age = int.Parse(textBox4.Text);
            appointment.gender = textBox2.Text;
            appointment.Phone = int.Parse(textBox10.Text);
            appointment.DoctorName = textBox6.Text;
            appointment.date = textBox8.Text;
            appointment.time = textBox9.Text;


            appointment.updateAppointment(appointment.AppointmentId, appointment.PatientId, appointment.PatientName, appointment.age, appointment.gender, appointment.Phone, appointment.DoctorName, appointment.date, appointment.time);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Appointment appointment = new Appointment();

            appointment.AppointmentId = int.Parse(textBox1.Text);

            appointment.deletePatient(appointment.AppointmentId);


        }

        private void button4_Click(object sender, EventArgs e)
        {
            Appointment appointment = new Appointment();

            appointment.AppointmentId = int.Parse(textBox1.Text);
            appointment.readData(appointment.AppointmentId);

            textBox5.Text = appointment.PatientId.ToString();
            textBox7.Text = appointment.PatientName.ToString();
            textBox4.Text = appointment.age.ToString();
            textBox1.Text = appointment.AppointmentId.ToString();
            textBox2.Text = appointment.gender.ToString();
            textBox10.Text = appointment.Phone.ToString();
            textBox6.Text = appointment.DoctorName.ToString();
            textBox8.Text = appointment.date.ToString();
            textBox9.Text = appointment.time.ToString();
           

        }
    }
}

