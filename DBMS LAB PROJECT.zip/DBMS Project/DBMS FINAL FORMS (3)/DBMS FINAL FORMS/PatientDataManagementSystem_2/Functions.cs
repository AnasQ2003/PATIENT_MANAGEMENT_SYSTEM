﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDataManagementSystem_2
{
    public partial class Functions : Form
    {
        public Functions()
        {
            InitializeComponent();
        }


        public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";

        private void DisplayAppointments(DateTime dateInput)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM GetUpcomingAppointments(@dateInput)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@dateInput", dateInput);

                SqlDataReader reader = command.ExecuteReader();

                DataTable dataTable = new DataTable();
                dataTable.Load(reader);

                dataGridView1.DataSource = dataTable;

                reader.Close();
            }
        }

        // Call the DisplayAppointments method with your desired date input
        // Example usage:

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime dateInput = DateTime.Parse(textBox1.Text);
            DisplayAppointments(dateInput);
        }


        private void DisplayPatientWardDetails(int patientID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM GetPatientWardDetails(@patientID)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@patientID", patientID);

                SqlDataReader reader = command.ExecuteReader();

                DataTable dataTable = new DataTable();
                dataTable.Load(reader);

                dataGridView3.DataSource = dataTable;

                reader.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int patientID= int.Parse(textBox2.Text);
            DisplayPatientWardDetails(patientID);
        }



        private void DisplayPatientMedicalSummary(int patientID)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM GetPatientMedicalSummary(@patientID)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@patientID", patientID);

                SqlDataReader reader = command.ExecuteReader();

                DataTable dataTable = new DataTable();
                dataTable.Load(reader);

                dataGridView4.DataSource = dataTable;

                reader.Close();
            }
        }


        private void button4_Click(object sender, EventArgs e)
        {
            int patientID = int.Parse(textBox3.Text);
            DisplayPatientMedicalSummary(patientID);
        }



        private void button2_Click(object sender, EventArgs e)
        {

            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            String Query = "select * from  GetDoctorPatientSummary()";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(Query, connection);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);

            dataGridView2.DataSource = dataTable;
        }

    }
}
