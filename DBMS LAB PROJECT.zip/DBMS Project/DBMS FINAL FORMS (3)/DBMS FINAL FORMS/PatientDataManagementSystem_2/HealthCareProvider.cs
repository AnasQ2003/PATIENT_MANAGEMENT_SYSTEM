﻿using PatientDataManagementSystem_2;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

public class HealthCareProvider
{
    private int doctorId;
    private String doctorName;
    private string jobTitle;
    private int doctorAge;
    private String department;
    private String doctorEducation;
    private String medicalDegree;
    private int doctorPhoneNo;
     


    public HealthCareProvider() { }

    public HealthCareProvider(int id, String name, string title, int age, String department, String education, String degree, int phoneNo)
    {
        this.doctorId = id;
        this.doctorName = name;
        this.jobTitle = title;
        this.doctorAge = age;
        this.department = department;
        this.doctorEducation = education;
        this.medicalDegree = degree;
        this.doctorPhoneNo = phoneNo;
    }



    public int DoctorId
    {
        get { return doctorId; }
        set { doctorId = value; }
    }

    public String DoctorName
    {
        get { return doctorName; }
        set { doctorName = value; }
    }

    public String Title
    {
        get { return jobTitle; }
        set { jobTitle = value; }
    }

    public int Age
    {
        get { return doctorAge; }
        set { doctorAge = value; }
    }

    public string Department
    {
        get { return department; }
        set { department = value; }
    }

    


    public string Education
    {
        get { return doctorEducation; }
        set { doctorEducation = value; }
    }
    public string MedicalDegree
    {
        get { return medicalDegree; }
        set { medicalDegree = value; }
    }
    public int PhoneNo
    {
        get { return doctorPhoneNo; }
        set { doctorPhoneNo = value; }
    }

   
    public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";



    public void AddDoctor(int id, string name,string title, int age, string department, string education ,string degree, int phoneNo)
    {

        SqlConnection connection = new SqlConnection(connectionString);


        connection.Open();
        string query = "INSERT INTO Patient (Doctor_Id,Doctor_Name,Job_Title,Age,Department,Education,Phone_No) VALUES (@id, @Name,@title,@age,@department,@education,@phoneNo)";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@id", id);
        command.Parameters.AddWithValue("@Name", name);
        command.Parameters.AddWithValue("@title", title);
        command.Parameters.AddWithValue("@age",age );
        command.Parameters.AddWithValue("@department", department);
        command.Parameters.AddWithValue("@education", education);
        //command.Parameters.AddWithValue("@Degree", degree);
        command.Parameters.AddWithValue("@phoneNo", phoneNo);
        
        


        int rowsAffected = command.ExecuteNonQuery();
        Console.WriteLine($"{rowsAffected} rows inserted.");
        connection.Close();

        MessageBox.Show("Successfully Inserted!", " Message");
    }

    public void updateDoctor(int id, string name, string title, int age, string department, string education, string degree, int phoneNo)
    {
        SqlConnection connection = new SqlConnection(connectionString);

        connection.Open();
        string query = "UPDATE Patient SET Doctor_Name = @name , Job_Title=@title , Age = @age , Department = @department, Education = @education , Phone_No=@phoneNo WHERE Doctor_Id = @id ";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@id", id);
        command.Parameters.AddWithValue("@name", name);
        command.Parameters.AddWithValue("@title", title);
        command.Parameters.AddWithValue("@age", age);
        command.Parameters.AddWithValue("@department", department);
        command.Parameters.AddWithValue("@education",education);
        command.Parameters.AddWithValue("@degree", degree);
        command.Parameters.AddWithValue("@phoneNo", phoneNo);
     


        int rowsAffected = command.ExecuteNonQuery();
        Console.WriteLine($"{rowsAffected} rows updated.");

        MessageBox.Show("Successfully Updated!", " Message");


    }

    public void deleteDoctor(int id)
    {
        SqlConnection connection = new SqlConnection(connectionString);
        connection.Open();
        string query = "DELETE FROM Patient WHERE Doctor_Id = @id";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@id", id);
        int rowsAffected = command.ExecuteNonQuery();
        Console.WriteLine($"{rowsAffected} rows deleted.");

        MessageBox.Show("Successfully Deleted!", " Message");


    }

    public void readData(int id)
    {
        SqlConnection connection = new SqlConnection(connectionString);

        connection.Open();
        string query = "SELECT * FROM Patient  WHERE Doctor_Id = @id";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@id", id);
        SqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
            doctorId = reader.GetInt32(0);
            doctorName = reader.GetString(1);
            jobTitle = reader.GetString(2);
            Age = reader.IsDBNull(3) ? 0 : reader.GetInt32(3);
            department = reader.GetString(4);
            doctorEducation = reader.GetString(5);
            doctorPhoneNo = reader.IsDBNull(6) ? 0 : reader.GetInt32(6);

        }

        reader.Close();


        MessageBox.Show("Data Found!", " Message");

    }


}
