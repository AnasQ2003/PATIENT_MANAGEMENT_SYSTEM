﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PatientDataManagementSystem_2
{
    public partial class Patient_App : Form
    {
        public Patient_App()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Patient_appointment pa = new Patient_appointment();

            pa.appointmetID = int.Parse(textBox1.Text);
            pa.PatientId = int.Parse(textBox7.Text);
            pa.DoctorID = int.Parse(textBox2.Text);


            pa.addPatientAppointment(pa.appointmetID, pa.PatientId, pa.DoctorID);

        }

        private void button1_Click(object sender, EventArgs e)
        {

            Patient_appointment pa = new Patient_appointment();

            pa.appointmetID = int.Parse(textBox1.Text);
            pa.PatientId = int.Parse(textBox7.Text);
            pa.DoctorID = int.Parse(textBox2.Text);


            pa.updatePatientapp(pa.appointmetID, pa.PatientId, pa.DoctorID);


        }

        private void button3_Click(object sender, EventArgs e)
        {
            Patient_appointment pa = new Patient_appointment();
            pa.appointmetID = int.Parse(textBox1.Text);


            pa.deletePatientapp(pa.appointmetID);


        }

        private void button4_Click(object sender, EventArgs e)
        {
            Patient_appointment pa = new Patient_appointment();

            pa.PatientId = int.Parse(textBox7.Text);
            pa.readDataapp(pa.PatientId);

            textBox1.Text = pa.appointmetID.ToString();
            textBox2.Text = pa.DoctorID.ToString();
          

        }
    }
}
