﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PatientDataManagementSystem_2
{
    public class EHR
    {
        private int e_PatientId;
        private String e_PatientName;
        private String e_Medications;
        private String e_Reports;
        private string e_MedicalHistory;
        private String e_BloodPressure;
        private int e_Weight;




        public EHR() { }

        public EHR(int id, String name, String medications, String reports, String medicalhistory, String bloodpressure,int weight)
        {
            this.e_PatientId = id;
            this.e_PatientName = name;
            this.e_Medications = medications;
            this.e_MedicalHistory= medicalhistory;
            this.e_Reports=reports;
            this.e_BloodPressure= bloodpressure;
            this.e_Weight= weight;
        }



        public int PatientId
        {
            get { return e_PatientId; }
            set { e_PatientId = value; }
        }

        public String PatientName
        {
            get { return e_PatientName; }
            set { e_PatientName = value; }
        }

        


        public string Medications
        {
            get { return e_Medications; }
            set { e_Medications = value; }
        }

        public string Reports
        {
            get { return e_Reports; }
            set { e_Reports = value; }
        }


        public string MedicalHistory
        {
            get { return e_MedicalHistory; }
            set { e_MedicalHistory = value; }
        }

        public String BloodPressure
        { 
            get { return e_BloodPressure; }
            set { e_BloodPressure = value; }
        }

        public int Weight
        {
            get { return e_Weight; }
            set { e_Weight = value; }
        }







        public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";



        public void addPatientEHR(int id, String name, String medications, String reports, String medicalhistory, String bloodpressure, int weight)
        {

            SqlConnection connection = new SqlConnection(connectionString);


            connection.Open();
            string query = "INSERT INTO EHR (Patient_Id,Patient_Name,Medical_History,Blood_Pressure,Weight,Reports,Medications) " +
                "VALUES (@e_PatientId, @e_PatientName, @medicalHistory,@bloodPressure,@weight,@reports,@medications)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@e_PatientId",id);
            command.Parameters.AddWithValue("@e_PatientName", name);
            command.Parameters.AddWithValue("@medicalHistory", medicalhistory);
            command.Parameters.AddWithValue("@medications", medications);
            command.Parameters.AddWithValue("@bloodPressure", bloodpressure );
            command.Parameters.AddWithValue("@weight", weight);
            command.Parameters.AddWithValue("@reports",reports);


            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows inserted.");
            connection.Close();

            MessageBox.Show("Successfully Inserted!", " Message");
        }

        public void updateEHR(int id, String name, String medications, String reports, String medicalhistory, String bloodpressure, int weight)
        {
            SqlConnection connection = new SqlConnection(connectionString);

            connection.Open();
            string query = "UPDATE EHR SET Patient_Name = @name ,Medical_History=@medicalHistory,Medications= @medications, Reports=@reports, Blood_Pressure=@bloodPressure,Weight=@weight WHERE Patient_Id = @id ";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id", id);
            command.Parameters.AddWithValue("@name", name);
            command.Parameters.AddWithValue("@medicalHistory",medicalhistory);
            command.Parameters.AddWithValue("@medications", medications);
            command.Parameters.AddWithValue("@bloodPressure", bloodpressure);
            command.Parameters.AddWithValue("@weight", weight);
            command.Parameters.AddWithValue("@reports", reports);


            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows updated.");

            MessageBox.Show("Successfully Updated!", " Message");


        }

        public void deleteEHR(int id)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string query = "DELETE FROM EHR WHERE Patient_Id = @id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id", id);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows deleted.");

            MessageBox.Show("Successfully Deleted!", " Message");


        }

        public void readData(int id)
        {
            SqlConnection connection = new SqlConnection(connectionString);

            connection.Open();
            string query = "SELECT * FROM EHR  WHERE Patient_Id = @id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id", id);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                e_PatientId = reader.GetInt32(0);
                e_PatientName = reader.GetString(1);
                e_Medications = reader.GetString(6);
                e_Reports = reader.GetString(5);
               e_MedicalHistory = reader.GetString(2);
                e_Weight = reader.GetInt32(4);
                e_BloodPressure= reader.GetString(3);

            }

            reader.Close();


            MessageBox.Show("Data Found!", " Message");

        }

    }
}

