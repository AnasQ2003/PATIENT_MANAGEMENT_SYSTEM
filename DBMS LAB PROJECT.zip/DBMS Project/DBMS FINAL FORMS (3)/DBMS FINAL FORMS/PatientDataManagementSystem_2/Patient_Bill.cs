﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PatientDataManagementSystem_2
{
    public partial class Patient_Bill : Form
    {
        public Patient_Bill()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PatientBill pb = new PatientBill();

            pb.BillID = int.Parse(textBox1.Text);
            pb.PatientId = int.Parse(textBox7.Text);


            pb.addPatientBill(pb.BillID, pb.PatientId);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PatientBill pb = new PatientBill();

            pb.BillID = int.Parse(textBox1.Text);
            pb.PatientId = int.Parse(textBox7.Text);


            pb.updatePatientBill(pb.BillID, pb.PatientId);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            PatientBill pb = new PatientBill();

            pb.BillID = int.Parse(textBox1.Text);
            pb.readDataBill(pb.BillID);

            textBox7.Text = pb.PatientId.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {

            PatientBill pb = new PatientBill();
            pb.BillID = int.Parse(textBox1.Text);


            pb.deletePatientBill(pb.PatientId);
        }
    }
}
