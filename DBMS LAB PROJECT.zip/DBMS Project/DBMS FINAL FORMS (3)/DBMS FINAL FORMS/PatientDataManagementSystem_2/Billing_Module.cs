﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PatientDataManagementSystem_2
{
    public partial class Billing_Module : Form
    {
        public Billing_Module()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Billing billing = new Billing();

            billing.BillingBillId = int.Parse(textBox1.Text);
            billing.BillStatus = textBox7.Text;
            billing.BillingAmount = int.Parse(textBox2.Text);
            billing.BillingDate = textBox6.Text;

            billing.addPatientBill(billing.BillingBillId,  billing.BillStatus, billing.BillingAmount, billing.BillingDate);

        }



        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Billing billing = new Billing();
            billing.BillingBillId = int.Parse(textBox1.Text);
            billing.BillStatus = textBox7.Text;
            billing.BillingAmount = int.Parse(textBox2.Text);
            billing.BillingDate = textBox6.Text;


            billing.updatePatient(billing.BillingBillId, billing.BillStatus, billing.BillingAmount, billing.BillingDate);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Billing billing = new Billing();

            billing.BillingBillId = int.Parse(textBox1.Text);

            billing.deleteBill(billing.BillingBillId);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Billing billing = new Billing();

            billing.BillingBillId = int.Parse(textBox1.Text);
            billing.readData(billing.BillingBillId);

            textBox2.Text = billing.BillingAmount.ToString();
            textBox7.Text = billing.BillStatus.ToString();          
            textBox6.Text = billing.BillingDate.ToString();
          

        }
    }
}
