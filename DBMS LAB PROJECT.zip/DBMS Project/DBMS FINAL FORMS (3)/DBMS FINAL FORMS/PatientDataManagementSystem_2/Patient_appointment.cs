﻿using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Net;

public class Patient_appointment
{
    private int appId;
    private int patientId;
    private int doctorId;


    public Patient_appointment() { }

    public Patient_appointment(int app_id, int pat_id,int doctor_id)
    {
        this.appId = app_id;
        this.patientId = pat_id;
        this.doctorId = doctor_id;

    }



    public int PatientId
    {
        get { return patientId; }
        set { patientId = value; }
    }

    public int appointmetID
    {
        get { return appId; }
        set { appId = value; }
    }

    public int DoctorID
    {
        get { return doctorId; }
        set { doctorId = value; }
    }










    public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";



    public void addPatientAppointment(int appid, int patid, int doctorid)
    {

        SqlConnection connection = new SqlConnection(connectionString);


        connection.Open();
        string query = "INSERT INTO Patient (Appointment_Id,Patient_Id,Doctor_Id) VALUES (@appid, @patid, @doctorid)";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@appid",appid);
        command.Parameters.AddWithValue("@patid", patid);
        command.Parameters.AddWithValue("@doctorid", doctorid);
        
        int rowsAffected = command.ExecuteNonQuery();
        Console.WriteLine($"{rowsAffected} rows inserted.");
        connection.Close();

        MessageBox.Show("Successfully Inserted!", " Message");
    }


    public void updatePatientapp(int appid, int patid, int doctorid)
    {
        SqlConnection connection = new SqlConnection(connectionString);

        connection.Open();
        string query = "UPDATE Patient SET Appointment_Id=@appid, Patient_Id = @patid , Doctor_Id=@doctorid WHERE Appointment_Id = @appid ";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@appid", appid);
        command.Parameters.AddWithValue("@patid", patid);
        command.Parameters.AddWithValue("@doctorid", doctorid);



        

        int rowsAffected = command.ExecuteNonQuery();
        Console.WriteLine($"{rowsAffected} rows updated.");

        MessageBox.Show("Successfully Updated!", " Message");


    }

    public void deletePatientapp(int appid)
    {
        SqlConnection connection = new SqlConnection(connectionString);
        connection.Open();
        string query = "DELETE FROM Patient WHERE Appointment_Id = @Id";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@Id",appid);
        int rowsAffected = command.ExecuteNonQuery();
        Console.WriteLine($"{rowsAffected} rows deleted.");

        MessageBox.Show("Successfully Deleted!", " Message");


    }


    public void readDataapp(int patid)
    {
        SqlConnection connection = new SqlConnection(connectionString);

        connection.Open();
        string query = "SELECT * FROM Patient  WHERE Patient_Id = @id";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@id", patid);
        SqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
            PatientId = reader.GetInt32(1);
          appointmetID= reader.GetInt32(7);
            doctorId = reader.GetInt32(2);

        }

        reader.Close();


        MessageBox.Show("Data Found!", " Message");

    }
    





}
