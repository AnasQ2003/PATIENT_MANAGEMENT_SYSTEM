﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PatientDataManagementSystem_2
{
    public partial class EHR_Module : Form
    {
        public EHR_Module()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            EHR ehr = new EHR();

            ehr.PatientId = int.Parse(textBox1.Text);
            ehr.PatientName = textBox5.Text;
            ehr.MedicalHistory = textBox2.Text;
            ehr.Reports = textBox3.Text;
            ehr.Medications = textBox6.Text;
            ehr.BloodPressure = textBox7.Text;
            ehr.Weight = int.Parse(textBox4.Text);

            ehr.addPatientEHR(ehr.PatientId, ehr.PatientName, ehr.Medications, ehr.Reports, ehr.MedicalHistory, ehr.BloodPressure,ehr.Weight);



        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EHR ehr = new EHR();

            ehr.PatientId = int.Parse(textBox1.Text);
            ehr.PatientName = textBox5.Text;
            ehr.MedicalHistory = textBox2.Text;
            ehr.Reports = textBox3.Text;
            ehr.Medications = textBox6.Text;
            ehr.BloodPressure = textBox7.Text;
            ehr.Weight = int.Parse(textBox4.Text);

            ehr.addPatientEHR(ehr.PatientId, ehr.PatientName, ehr.Medications, ehr.Reports, ehr.MedicalHistory, ehr.BloodPressure, ehr.Weight);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            EHR ehr = new EHR();

            ehr.PatientId = int.Parse(textBox1.Text);
            ehr.readData(ehr.PatientId);

            textBox5.Text = ehr.PatientName.ToString();
            textBox7.Text = ehr.BloodPressure.ToString();
            textBox4.Text = ehr.Weight.ToString();
            textBox3.Text = ehr.Reports.ToString();
            textBox2.Text = ehr.MedicalHistory.ToString();
            textBox6.Text = ehr.Medications.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            EHR ehr = new EHR();

            ehr.PatientId = int.Parse(textBox1.Text);

            ehr.deleteEHR(ehr.PatientId);

        }
    }
}
