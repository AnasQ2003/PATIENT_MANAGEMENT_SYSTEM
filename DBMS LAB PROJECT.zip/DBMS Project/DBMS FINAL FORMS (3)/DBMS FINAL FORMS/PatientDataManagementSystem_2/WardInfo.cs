﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDataManagementSystem_2
{
    public class WardInfo
    {
        private int wardNo;
        private int chargeperDay;
        private int bedCapacity;
        private string wardName;
        private string wardType;

        public WardInfo() { }

        public WardInfo(int wardno, int chargeperday, int bedcapacity,string wardname, string wardtype)
        {
            this.wardNo = wardno;
            this.chargeperDay = chargeperday;
            this.bedCapacity= bedcapacity;
            this.wardName= wardname;
            this.wardType= wardtype;

        }



        public int chargeperday
        {
            get { return chargeperDay; }
            set { chargeperDay = value; }
        }

        public int WardNo
        {
            get { return wardNo; }
            set { wardNo = value; }
        }

        public int bedcapacity
        {
            get { return bedCapacity; }
            set { bedCapacity = value; }
        }
        public string wardname
        {
            get { return wardName; }
            set { wardName = value; }

        }
        public string wardtype
        {
            get { return wardType; }
            set { wardType = value; }
        }

        public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";



        public void addWardInfo(int wardno, int chargeperday, int bedcapacity,string wardname, string wardtype)
        {

            SqlConnection connection = new SqlConnection(connectionString);


            connection.Open();
            string query = "INSERT INTO WardInfo (Ward_No,ChargePerDay,Bed_Capacity,Ward_Name,Ward_Type) VALUES (@wardno, @chargeperday,@bedcapacity,@wardname,@wardtype)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@wardno", wardno);
            command.Parameters.AddWithValue("@chargeperday", chargeperday);
            command.Parameters.AddWithValue("@bedcapacity", bedcapacity);
            command.Parameters.AddWithValue("@wardname", wardname);
            command.Parameters.AddWithValue("@wardtype", wardtype);


            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows inserted.");
            connection.Close();

            MessageBox.Show("Successfully Inserted!", " Message");
        }


        public void updateWardInfo(int wardno, int chargeperday, int bedcapacity, string wardname, string wardtype)
        {
            SqlConnection connection = new SqlConnection(connectionString);

            connection.Open();
            string query = "UPDATE WardInfo SET Ward_No=@wardno, ChargePerDay = @chargeperday,Ward_Name=@wardname,Ward_Type=@wardtype WHERE Ward_No = @wardno";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@wardno", wardno);
            command.Parameters.AddWithValue("@chargeperday", chargeperday);
            command.Parameters.AddWithValue("@bedcapacity", bedcapacity);
            command.Parameters.AddWithValue("@wardname", wardname);
            command.Parameters.AddWithValue("@wardtype", wardtype);




            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows updated.");

            MessageBox.Show("Successfully Updated!", " Message");


        }

        public void deletePatientWard(int wardno)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string query = "DELETE FROM WardInfo WHERE WardNo = @wardno";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id", wardno);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows deleted.");

            MessageBox.Show("Successfully Deleted!", " Message");


        }


        public void readDataWard(int wardno)
        {
            SqlConnection connection = new SqlConnection(connectionString);

            connection.Open();
            string query = "SELECT * FROM WardInfo  WHERE Ward_No = @wardno";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@wardno", wardno);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                wardNo = reader.GetInt32(0);
                chargeperDay = reader.GetInt32(3);
                bedCapacity = reader.GetInt32(4);
                wardName = reader.GetString(1);
                wardType = reader.GetString(2);
            }

            reader.Close();


            MessageBox.Show("Data Found!", " Message");

        }

    }

}
