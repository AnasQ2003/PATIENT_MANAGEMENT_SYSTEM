﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace PatientDataManagementSystem_2
{
    public class Patient
    {
        private int patientId;
        private String patientName;
        private int age;
        private String Address;
        private String Gender;
        private String Occupation;
        private int phoneNo;
        private int insuranceNo;


        public Patient() { }

        public Patient(int id,String name,int age ,String address,String Gender,String occupation,int phoneNo,int insuranceNo )
        {
            this.patientId = id;
            this.patientName = name;
            this.age = age;
            this.Address = address;
            this.Gender = Gender;
            this.Occupation = occupation;
            this.phoneNo = phoneNo;
            this.insuranceNo = insuranceNo;
        }



        public int PatientId
        {
            get { return patientId; }
            set { patientId = value; }
        }

        public String PatientName
        {
            get { return patientName; }
            set { patientName = value; }
        }

        public String address
        {
            get { return Address; }
            set { Address = value; }
        }



        public string gender
        {
            get { return Gender; }
            set { Gender = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }


        public string occupation
        {
            get { return Occupation; }
            set { Occupation = value; }
        }

        public int PhoneNo
        {
            get { return phoneNo; }
            set { phoneNo = value; }
        }

        public int InsuranceNo
        {
            get { return insuranceNo; }
            set { insuranceNo = value; }
        }









        public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";



        public void addPatient (int id,string name,int age,string address,string gender,int phoneNo,string Occupation,int insuranceNo)
        {

        SqlConnection connection = new SqlConnection(connectionString);


            connection.Open();
            string query = "INSERT INTO Patient (Patient_Id,Patient_Name,Age,Patient_Address,Gender,Phone_No," +
                "Occupation,Insurance_No) VALUES (@id, @Name, @age,@address,@gender,@phoneNo,@Occupation,@InsuranceNo)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id",id);
            command.Parameters.AddWithValue("@Name", name);
            command.Parameters.AddWithValue("@age", age);
            command.Parameters.AddWithValue("@address", address);
            command.Parameters.AddWithValue("@gender",gender);
            command.Parameters.AddWithValue("@phoneNo", phoneNo);
            command.Parameters.AddWithValue("@Occupation", Occupation);
            command.Parameters.AddWithValue("@InsuranceNo", insuranceNo);


            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows inserted.");
            connection.Close();

            MessageBox.Show("Successfully Inserted!", " Message");
        }



        public void updatePatient(int id, string name, int age, string address, string gender, int phoneNo, string Occupation, int insuranceNo)
        {
            SqlConnection connection = new SqlConnection(connectionString);

            connection.Open();
            string query = "UPDATE Patient SET Patient_Name = @name , Age = @age , Patient_Address = @address, Gender=@gender,Phone_No=@phoneNo,Occupation=@Occupation,Insurance_No=@insuranceNo WHERE Patient_Id = @id ";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id", id);
            command.Parameters.AddWithValue("@name", name);
            command.Parameters.AddWithValue("@age", age);
            command.Parameters.AddWithValue("@address", address);
            command.Parameters.AddWithValue("@gender", gender);
            command.Parameters.AddWithValue("@phoneNo", phoneNo);
            command.Parameters.AddWithValue("@Occupation", Occupation);
            command.Parameters.AddWithValue("@insuranceNo", insuranceNo);


            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows updated.");

            MessageBox.Show("Successfully Updated!", " Message");


        }

        public void deletePatient(int id)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string query = "DELETE FROM Patient WHERE Patient_Id = @Id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id", id);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows deleted.");

            MessageBox.Show("Successfully Deleted!", " Message");


        }


        public void readData(int id)
        {
            SqlConnection connection = new SqlConnection(connectionString);

            connection.Open();
            string query = "SELECT * FROM Patient  WHERE Patient_Id = @id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id", id);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                PatientId = reader.GetInt32(0);
                PatientName = reader.GetString(1);
                Age = reader.IsDBNull(7) ? 0 : reader.GetInt32(7);
                address = reader.GetString(2);
                gender = reader.GetString(3);
                PhoneNo = reader.GetInt32(4);
                occupation = reader.GetString(5);
                InsuranceNo = reader.IsDBNull(6) ? 0 : reader.GetInt32(6);

            }

            reader.Close();


            MessageBox.Show("Data Found!", " Message");

        }








    }
}
